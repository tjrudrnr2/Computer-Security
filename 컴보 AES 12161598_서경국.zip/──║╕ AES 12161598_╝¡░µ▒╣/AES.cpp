#include <iostream>
#include <fstream>
using namespace std;

typedef unsigned char uint;
#define KEYSIZE 16
#define Irreducible_polynomial 0b111100111
char key[16]; // key ���� �迭
char plain_Arr[16]; // plain ���� �迭
char cyper_Arr[16]; // cyper ���� �迭
uint plain_Arr_dec[4][4]; // plain ���� 4x4 ���
uint cyper_Arr_dec[4][4]; // cyper ���� 4x4 ���
uint key_table[4][4];	// key ���� 4x4 ���
uint expanded_Key[176][4]; // expanded key ���� �迭
uint RC[11];		// RC�� ���� �迭
uint A[8][8] =	// SubBytes���� ��İ� �� ���
{ {1,0,0,0,1,1,1,1},
{1,1,0,0,0,1,1,1},
{1,1,1,0,0,0,1,1},
{1,1,1,1,0,0,0,1},
{1,1,1,1,1,0,0,0},
{0,1,1,1,1,1,0,0},
{0,0,1,1,1,1,1,0},
{0,0,0,1,1,1,1,1} };
uint A_inv[8][8] =	// A����� �����
{ {0,0,1,0,0,1,0,1},
{1,0,0,1,0,0,1,0},
{0,1,0,0,1,0,0,1},
{1,0,1,0,0,1,0,0},
{0,1,0,1,0,0,1,0},
{0,0,1,0,1,0,0,1},
{1,0,0,1,0,1,0,0},
{0,1,0,0,1,0,1,0} };
uint C[8] = { 1,1,0,0,0,1,1,0 };	// SubBytes���� ���� �������
uint C_inv[8] = { 1,0,1,0,0,0,0,0 }; // C�� �����
int MC[4][4] =	// MixColumns���� ��İ� �� ���
{ {2,3,1,1},
{1,2,3,1},
{1,1,2,3},
{3,1,1,2} };
int MC_inv[4][4] =	// MC�� �����
{ {14,11,13,9},
{9,14,11,13},
{13,9,14,11},
{11,13,9,14} };

// �ʱ�ȭ
void clear()
{
	for (int i = 0; i < KEYSIZE; i++)
	{
		key[i] = 0;
		plain_Arr[i] = 0;
		cyper_Arr[i] = 0;
	}
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			plain_Arr_dec[i][j] = 0;
			cyper_Arr_dec[i][j] = 0;
			key_table[i][j] = 0;
		}
	}
}
void plainToArr()
{
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			plain_Arr_dec[j][i] = (uint)plain_Arr[4 * i + j]
		}
	}
}	 
void cyperToArr()
{
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			cyper_Arr_dec[j][i] = (uint)cyper_Arr[4 * i + j];
		}
	}
}
int deg(int bp)
{
//	cout << "bp : " << bp << '\n';
	for (int i = 8; i > 0; i--)
	{
		if ((bp & (1 << i)) != 0)
		{
			return i;
		}
	}
	return 0;
}
int bin_inv(int a)
{
//	cout << "now : " << a << '\n';
	int u = a;
	int v = Irreducible_polynomial;
	int g1 = 1, g2 = 0, h1 = 0, h2 = 1;
	while (u != 0)
	{
		int j = deg(u) - deg(v);
//		cout << "j : " << j << '\n';
		if (j < 0)
		{
			int swp = v;
			v = u;
			u = swp;
			swp = g2;
			g2 = g1;
			g1 = swp;
			swp = h2;
			h2 = h1;
			h1 = swp;
			j = -j;
		}
		u = u ^ (v << j);
		g1 = g1 ^ (g2 << j);
		h1 = h1 ^ (h2 << j);
	}
//	cout << "g2 : " << g2 << '\n';
	return g2;
}
// RC���� �̸� ����Ͽ� ����
void getRC()
{
	RC[1] = 1;
	for (int i = 2; i <= 8; i++)
	{
		RC[i] = RC[i - 1] << 1;
	}
	RC[9] = 0xE7;
	RC[10] = 0x29;
}
// GF()�� �̿��� S-box ���
uint SBOX(uint val)
{
	uint value_inv;
	value_inv = bin_inv(val); // �������ϱ�

	// ������ 2������ ��ȯ
	int value_inv_bin[8];
	for (int i = 0; i < 8; i++)
	{
		if ((value_inv & (1 << i)) == 0)
		{
			value_inv_bin[i] = 0;
		}
		else
		{
			value_inv_bin[i] = 1;
		}
	}
	// ��İ� 
	int result_bin[8];
	for (int i = 0; i < 8; i++)
	{
		int res_bit[8];
		for (int j = 0; j < 8; j++)
		{
			res_bit[j] = A[i][j] & value_inv_bin[j];
		}
		result_bin[i] = res_bit[0];
		for (int j = 1; j < 8; j++)
		{
			result_bin[i] ^= res_bit[j];
		}
		result_bin[i] ^= C[i];
	}
	// result_bin�� 10������ ��ȯ
	uint tmp = 1;
	uint result = 0;
	for (int i = 0; i < 8; i++)
	{
		result += tmp * result_bin[i];
		tmp *= 2;
	}

	return result;
}
uint SBOX_inv(uint val)
{
	int value_bin[8];
	for (int i = 0; i < 8; i++)
	{
		if ((val & (1 << i)) == 0)
		{
			value_bin[i] = 0;
		}
		else
		{
			value_bin[i] = 1;
		}
	}
	// ��İ� 
	int result_bin[8];
	for (int i = 0; i < 8; i++)
	{
		int res_bit[8];
		for (int j = 0; j < 8; j++)
		{
			res_bit[j] = A_inv[i][j] & value_bin[j];
		}
		result_bin[i] = res_bit[0];
		for (int j = 1; j < 8; j++)
		{
			result_bin[i] ^= res_bit[j];
		}
		result_bin[i] ^= C_inv[i];
	}
	// result_bin�� 10������ ��ȯ
	uint tmp = 1;
	uint result = 0;
	for (int i = 0; i < 8; i++)
	{
		result += tmp * result_bin[i];
		tmp *= 2;
	}
	return bin_inv(result);
}
// key expansion�� ���� g�Լ�
void functionG(int idx)
{
	// nowWord�� g�Լ��� �� word i.g.)w3, w7 ... 
	uint nowWord[4];
	for (int i = 0; i < 4; i++)
	{
		nowWord[i] = expanded_Key[4 * (idx - 1) + i][3];
	}	
	uint tmp = nowWord[0];
	for (int i = 0; i < 3; i++)
	{
		nowWord[i] = nowWord[i + 1];
	}
	nowWord[3] = tmp;
	
	// s-box ���
	for (int i = 0; i < 4; i++)
	{
		nowWord[i] = SBOX(nowWord[i]);
	}

	// RC(i)�� XOR�ؼ� w'�� ����
	nowWord[0] = nowWord[0] ^ RC[idx];
	for (int i = 1; i < 4; i++)
	{
		nowWord[i] = nowWord[i] ^ 0;
	}

	// Ű ����
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			if (i == 0)
			{
				expanded_Key[4 * idx + j][0] =
					expanded_Key[4 * (idx - 1) + j][0] ^ nowWord[j];
			}
			else
			{
				expanded_Key[4 * idx + j][i] =
					expanded_Key[4 * idx + j][i - 1] ^
						expanded_Key[4 * (idx - 1) + j][i];
			}
		}
	}
}
bool carry(int a)
{
	if (a & 0x100)
	{
		return true;
	}
	else
	{
		return false;
	}
}
uint bin_mul(int a, int b)
{
	int buf = Irreducible_polynomial & 0xff;
	int f[8];
	f[0] = a;
	for (int i = 1; i < 8; i++)
	{
		f[i] = f[i - 1] << 1;
		if (carry(f[i]))
		{
			f[i] &= 0xff;
			f[i] ^= buf;
		}
	}
	uint res = 0;
	for (int i = 0; i < 8; i++)
	{
		int mask = 1 << i;
		if ((b & mask) != 0)
		{
			res ^= f[i];
		}
	}
	return res;
}
void KeyExpansion()
{
	// K1�� ó�� Ű�� ���� ������ �״�� ����
	for (int i = 0; i < 4; i++)
	{
		for (int j = i * 4; j < (i + 1) * 4; j++)
		{
			key_table[j % 4][i] = key[j];
			expanded_Key[j % 4][i] = key_table[j % 4][i];
		}
	}
	getRC();
	// Ű 10�� ����
	for (int i = 1; i < 11; i++)
	{
		functionG(i);
	}
}
void AddroundKey(int num)
{
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			plain_Arr_dec[j][i] ^= expanded_Key[4 * num + j][i];
		}
	}
}
void AddroundKey_inv(int num)
{
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			cyper_Arr_dec[j][i] ^= expanded_Key[4 * num + j][i];
		}
	}
}
void SubBytes()
{
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			plain_Arr_dec[i][j] = SBOX(plain_Arr_dec[i][j]);
		}
	}
}
void SubBytes_inv()
{
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			cyper_Arr_dec[i][j] = SBOX_inv(cyper_Arr_dec[i][j]);
		}
	}
}
void ShiftRows()
{
	int tmp = 0;
	// �ީP���� ��ĭ��
	tmp = plain_Arr_dec[1][0];
	for (int i = 0; i < 3; i++)
	{
		plain_Arr_dec[1][i] = plain_Arr_dec[1][i + 1];
	}
	plain_Arr_dec[1][3] = tmp;

	// ��ĭ�� �̵�
	tmp = plain_Arr_dec[2][2];
	plain_Arr_dec[2][2] = plain_Arr_dec[2][0];
	plain_Arr_dec[2][0] = tmp;
	tmp = plain_Arr_dec[2][3];
	plain_Arr_dec[2][3] = plain_Arr_dec[2][1];
	plain_Arr_dec[2][1] = tmp;

	// ���������� ��ĭ�� �̵�
	tmp = plain_Arr_dec[3][3];
	for (int i = 3; i > 0; i--)
	{
		plain_Arr_dec[3][i] = plain_Arr_dec[3][i - 1];
	}
	plain_Arr_dec[3][0] = tmp;
}
void ShiftRows_inv()
{
	int tmp = 0;
	tmp = cyper_Arr_dec[1][3];
	for (int i = 3; i > 0; i--)
	{
		cyper_Arr_dec[1][i] = cyper_Arr_dec[1][i - 1];
	}
	cyper_Arr_dec[1][0] = tmp;

	tmp = cyper_Arr_dec[2][2];
	cyper_Arr_dec[2][2] = cyper_Arr_dec[2][0];
	cyper_Arr_dec[2][0] = tmp;
	tmp = cyper_Arr_dec[2][3];
	cyper_Arr_dec[2][3] = cyper_Arr_dec[2][1];
	cyper_Arr_dec[2][1] = tmp;

	tmp = cyper_Arr_dec[3][0];
	for (int i = 0; i < 3; i++)
	{
		cyper_Arr_dec[3][i] = cyper_Arr_dec[3][i + 1];
	}
	cyper_Arr_dec[3][3] = tmp;
}
void MixColumns()
{
	for (int i = 0; i < 4; i++)
	{
		int mixWord[4] = { 0,0,0,0 };
		for (int j = 0; j < 4; j++)
		{
			for (int k = 0; k < 4; k++)
			{
				mixWord[j] ^= bin_mul(MC[j][k], (int)plain_Arr_dec[k][i]);
			}
		}
		for (int j = 0; j < 4; j++)
		{
			plain_Arr_dec[j][i] = mixWord[j];
		}
	}
}
void MixColumns_inv()
{
	for (int i = 0; i < 4; i++)
	{
		int mixWord[4] = { 0,0,0,0 };
		for (int j = 0; j < 4; j++)
		{
			for (int k = 0; k < 4; k++)
			{
				mixWord[j] ^= 
					bin_mul(MC_inv[j][k], (int)cyper_Arr_dec[k][i]);
			}
		}
		for (int j = 0; j < 4; j++)
		{
			cyper_Arr_dec[j][i] = mixWord[j];
		}
	}
}
int main(int argc, char* argv[])
{
	char c = argv[1][0];
	switch (c)
	{
	case 'e':
	{
		string key_file = argv[2];
		string plain_file = argv[3];
		fstream inp;
		inp.open(key_file, ios::in | ios::binary);
		inp.read(key, KEYSIZE);
		fstream plain;
		plain.open(plain_file, ios::in | ios::binary);
		string cyper_file = "cipher.bin";
		fstream cyper;
		cyper.open(cyper_file, ios::out | ios::trunc | ios::binary);

		plain.seekg(0, ios::end);
		int fileSIZE = plain.tellg();
		plain.seekg(0, ios::beg);
		int encryption_cnt = fileSIZE / KEYSIZE; // block�� ����

		KeyExpansion(); // Ű Ȯ��

		for (int t = 0; t < encryption_cnt; t++)
		{
			plain.read(plain_Arr, KEYSIZE);
			plainToArr(); // key �迭�� 4x4��Ŀ� ����

			AddroundKey(0);
			for (int i = 1; i <= 9; i++)
			{
				SubBytes();
				ShiftRows();
				MixColumns();
				AddroundKey(i);
			}
			SubBytes();
			ShiftRows();
			AddroundKey(10);

			for (int i = 0; i < 4; i++)
			{
				for (int j = 0; j < 4; j++)
				{
					// 4x4 ����� key�� key�迭�� ������Ʈ
					plain_Arr[i * 4 + j] = (char)plain_Arr_dec[j][i];
				}			
			}
			cyper.write(plain_Arr, KEYSIZE);
			clear();
		}
		inp.close();
		plain.close();
		cyper.close();

		break;
	}
	case 'd':
	{
		string key_file = argv[2];
		string cyper_file = argv[3];
		fstream inp;
		inp.open(key_file, ios::in | ios::binary);
		inp.read(key, KEYSIZE);
		fstream cyper;
		cyper.open(cyper_file, ios::in | ios::binary);
		string plain_file = "plain2.bin";
		fstream plain;
		plain.open(plain_file, ios::out | ios::trunc | ios::binary);

		cyper.seekg(0, ios::beg);
		cyper.seekg(0, ios::end);
		int fileSIZE = cyper.tellg();
		cyper.seekg(0, ios::beg);
		int decryption_cnt = fileSIZE / KEYSIZE;

		KeyExpansion();

		for (int t = 0; t < decryption_cnt; t++)
		{
			cyper.read(cyper_Arr, KEYSIZE);
			cyperToArr(); // cyper ������ 4x4��Ŀ� ����

			AddroundKey_inv(10);
			for (int i = 1; i <= 9; i++)
			{
				ShiftRows_inv();
				SubBytes_inv();
				AddroundKey_inv(10 - i);
				MixColumns_inv();
			}
			SubBytes_inv();
			ShiftRows_inv();
			AddroundKey_inv(0);

			for (int i = 0; i < 4; i++)
			{
				for (int j = 0; j < 4; j++)
				{
					// 4x4 ��ķκ��� �迭�� ������Ʈ
					cyper_Arr[i * 4 + j] = (char)cyper_Arr_dec[j][i];
				}
			}
			plain.write(cyper_Arr, KEYSIZE);
			clear();
		}
		inp.close();
		plain.close();
		cyper.close();
		break;
	}
	default:
		break;
	}
}